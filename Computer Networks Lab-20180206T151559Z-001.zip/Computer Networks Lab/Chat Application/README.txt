To run:-

On one terminal run server as mentioned below:-
$ cd Networking\ Workshop/
$ cd Chat\ Application/
$ gcc Chatserver.c
$ ./a.out 5000

On another terminal run client as mentioned below:-
$ cd Networking\ Workshop/
$ cd Chat\ Application/
$ gcc Chatclient.c
$ ./a.out 5000

Note:- To close the server,use ctrl+c.

It demontrates chat application between client and server.
