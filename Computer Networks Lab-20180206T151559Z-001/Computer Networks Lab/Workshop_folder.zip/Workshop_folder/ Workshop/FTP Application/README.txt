To run:-

On one terminal run server as mentioned below:-
$ cd Networking\ Workshop/
$ cd FTP\ Application/
$ gcc ftpserver.c
$ ./a.out 5000

On another terminal run client as mentioned below:-
$ cd Networking\ Workshop/
$ cd FTP\ Application/
$ gcc ftpclient.c
$ ./a.out 5000

Note:- To close the server,use ctrl+c.


