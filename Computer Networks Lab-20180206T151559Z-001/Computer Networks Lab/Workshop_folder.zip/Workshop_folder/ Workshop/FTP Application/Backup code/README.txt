To run:-

On one terminal run server as mentioned below:-
$ cd Networking\ Workshop/
$ cd FTP\ Application/
$ cd Backup\ code/
$ gcc sserver.c
$ ./a.out 

On another terminal run client as mentioned below:-
$ cd Networking\ Workshop/
$ cd FTP\ Application/
$ cd Backup\ code/
$ gcc sclient.c
$ ./a.out 

Note:- To close the server,use ctrl+c or type exit.
       To close the client, type exit. This disconnects that particular client, but server can accept other clients.


